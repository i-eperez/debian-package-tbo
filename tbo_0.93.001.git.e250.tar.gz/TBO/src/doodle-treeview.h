#ifndef __TBO_DOODLE_VIEW__
#define __TBO_DOODLE_VIEW__

#include <gtk/gtk.h>
#include "tbo-window.h"

GtkWidget * doodle_setup_tree (TboWindow *tbo);
void doodle_free_all ();

#endif
