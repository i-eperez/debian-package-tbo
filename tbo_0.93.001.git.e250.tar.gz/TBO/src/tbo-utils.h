#ifndef __TBO_UTILS__
#define __TBO_UTILS__

#include <gtk/gtk.h>

void get_base_name (gchar *str, gchar *ret, int size);

#endif
