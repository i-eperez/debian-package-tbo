#ifndef __TBO_CUSTOM_STOCK__
#define __TBO_CUSTOM_STOCK__

#define TBO_STOCK_FRAME "tbo-newframe"
#define TBO_STOCK_SELECTOR "tbo-selector"
#define TBO_STOCK_DOODLE "tbo-doodle"
#define TBO_STOCK_TEXT "tbo-text"
#define TBO_STOCK_PIX "tbo-pix"

void load_custom_stock ();

#endif

