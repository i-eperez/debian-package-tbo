#ifndef __TBO_FILES__
#define __TBO_FILES__

char **tbo_files_get_dirs ();
int tbo_files_prefix_len (char *str);
void tbo_files_free (char **files);

#endif
