#ifndef __TBO_COMIC_LOAD__
#define __TBO_COMIC_LOAD__

#include "tbo-types.h"

Comic *tbo_comic_load (char *filename);

#endif
