#ifndef __TBO_EXPORT__
#define __TBO_EXPORT__

#include <gtk/gtk.h>
#include <cairo.h>
#include "tbo-window.h"

gboolean tbo_export (TboWindow *tbo, const char *);

#endif
