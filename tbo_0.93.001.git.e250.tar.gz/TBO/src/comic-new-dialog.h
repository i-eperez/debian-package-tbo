#ifndef __TBO_COMIC_NEW_DIALOG__
#define __TBO_COMIC_NEW_DIALOG__

#include <gtk/gtk.h>
#include "tbo-window.h"

gboolean tbo_comic_new_dialog (GtkWidget *widget, TboWindow *window);

#endif

